import Vue from 'vue'

const globalComponents = {
  Avatar: () => import('../..\\components\\ui\\Avatar.vue' /* webpackChunkName: "components_ui/Avatar" */).then(c => c.default || c),
  Btn: () => import('../..\\components\\ui\\Btn.vue' /* webpackChunkName: "components_ui/Btn" */).then(c => c.default || c),
  BtnBadge: () => import('../..\\components\\ui\\BtnBadge.vue' /* webpackChunkName: "components_ui/BtnBadge" */).then(c => c.default || c),
  BtnIcon: () => import('../..\\components\\ui\\BtnIcon.vue' /* webpackChunkName: "components_ui/BtnIcon" */).then(c => c.default || c),
  Card: () => import('../..\\components\\ui\\Card.vue' /* webpackChunkName: "components_ui/Card" */).then(c => c.default || c),
  Editor: () => import('../..\\components\\ui\\Editor.vue' /* webpackChunkName: "components_ui/Editor" */).then(c => c.default || c),
  Icon: () => import('../..\\components\\ui\\Icon.vue' /* webpackChunkName: "components_ui/Icon" */).then(c => c.default || c),
  ItemsList: () => import('../..\\components\\ui\\ItemsList.vue' /* webpackChunkName: "components_ui/ItemsList" */).then(c => c.default || c),
  Modal: () => import('../..\\components\\ui\\Modal.vue' /* webpackChunkName: "components_ui/Modal" */).then(c => c.default || c),
  Popover: () => import('../..\\components\\ui\\Popover.vue' /* webpackChunkName: "components_ui/Popover" */).then(c => c.default || c),
  ResponsiveImage: () => import('../..\\components\\ui\\ResponsiveImage.vue' /* webpackChunkName: "components_ui/ResponsiveImage" */).then(c => c.default || c),
  Tabs: () => import('../..\\components\\ui\\Tabs.vue' /* webpackChunkName: "components_ui/Tabs" */).then(c => c.default || c),
  TextInput: () => import('../..\\components\\ui\\TextInput.vue' /* webpackChunkName: "components_ui/TextInput" */).then(c => c.default || c),
  Tooltip: () => import('../..\\components\\ui\\Tooltip.vue' /* webpackChunkName: "components_ui/Tooltip" */).then(c => c.default || c)
}

for (const name in globalComponents) {
  Vue.component(name, globalComponents[name])
}
