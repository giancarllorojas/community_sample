import Vue from 'vue'
import Router from 'vue-router'
import { normalizeURL, decode } from '@nuxt/ufo'
import { interopDefault } from './utils'
import scrollBehavior from './router.scrollBehavior.js'

const _32834842 = () => interopDefault(import('..\\pages\\configuracoes.vue' /* webpackChunkName: "pages/configuracoes" */))
const _b9c8c400 = () => interopDefault(import('..\\pages\\configuracoes\\index.vue' /* webpackChunkName: "pages/configuracoes/index" */))
const _9e7a25a6 = () => interopDefault(import('..\\pages\\configuracoes\\geral.vue' /* webpackChunkName: "pages/configuracoes/geral" */))
const _4893c3fa = () => interopDefault(import('..\\pages\\configuracoes\\senha.vue' /* webpackChunkName: "pages/configuracoes/senha" */))
const _75da983d = () => interopDefault(import('..\\pages\\customizar.vue' /* webpackChunkName: "pages/customizar" */))
const _4356fee1 = () => interopDefault(import('..\\pages\\c\\_id.vue' /* webpackChunkName: "pages/c/_id" */))
const _106bd418 = () => interopDefault(import('..\\pages\\index.vue' /* webpackChunkName: "pages/index" */))

// TODO: remove in Nuxt 3
const emptyFn = () => {}
const originalPush = Router.prototype.push
Router.prototype.push = function push (location, onComplete = emptyFn, onAbort) {
  return originalPush.call(this, location, onComplete, onAbort)
}

Vue.use(Router)

export const routerOptions = {
  mode: 'history',
  base: '/',
  linkActiveClass: 'nuxt-link-active',
  linkExactActiveClass: 'nuxt-link-exact-active',
  scrollBehavior,

  routes: [{
    path: "/configuracoes",
    component: _32834842,
    children: [{
      path: "",
      component: _b9c8c400,
      name: "configuracoes"
    }, {
      path: "geral",
      component: _9e7a25a6,
      name: "configuracoes-geral"
    }, {
      path: "senha",
      component: _4893c3fa,
      name: "configuracoes-senha"
    }]
  }, {
    path: "/customizar",
    component: _75da983d,
    name: "customizar"
  }, {
    path: "/c/:id?",
    component: _4356fee1,
    name: "c-id"
  }, {
    path: "/",
    component: _106bd418,
    name: "index"
  }],

  fallback: false
}

function decodeObj(obj) {
  for (const key in obj) {
    if (typeof obj[key] === 'string') {
      obj[key] = decode(obj[key])
    }
  }
}

export function createRouter () {
  const router = new Router(routerOptions)

  const resolve = router.resolve.bind(router)
  router.resolve = (to, current, append) => {
    if (typeof to === 'string') {
      to = normalizeURL(to)
    }
    const r = resolve(to, current, append)
    if (r && r.resolved && r.resolved.query) {
      decodeObj(r.resolved.query)
    }
    return r
  }

  return router
}
