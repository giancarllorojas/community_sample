<template>
  <div class="p-3">
    <TextInput placeholder="Seu Nome" label="Nome de exibição"/>
    <TextInput class="mt-2" placeholder="Cidade onde você mora" label="Cidade"/>
    <TextInput placeholder="Seu Nome" label="Nome"/>
  </div>
</template>

<script>
export default {

}
</script>

<style>

</style>