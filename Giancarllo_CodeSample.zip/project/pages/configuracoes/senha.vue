<template>
  <div class="password p-3">
    <TextInput class="mt-2" placeholder="Digite sua nova senha" label="Nova senha"/>
    <TextInput placeholder="Confirme a senha" label="Confirme a senha"/>
  </div>
</template>

<script>
export default {

}
</script>

<style lang="sass" scoped>

</style>