<template>
  <div class="container">
    <AppContainer>
      <div class="channels">

      </div>
    </AppContainer>
  </div>
</template>

<script>
export default {

}
</script>

<style>

</style>