<template>
  <div class="post-reply">
    
  </div>
</template>

<script>
export default {

}
</script>

<style lang="sass" scoped>

</style>