export default {
  currentUser(state){
    return state.user
  }
}