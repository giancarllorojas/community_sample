export default () => ({
  user: {
    name: 'Giancarllo Rojas',
    avatar: 'https://i.imgur.com/Frb0oKA.png'
  },
  // user: null
})