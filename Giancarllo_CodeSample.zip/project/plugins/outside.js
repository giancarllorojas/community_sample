import Vue from 'vue'
import vOutsideEvents from 'vue-outside-events'
 
Vue.use(vOutsideEvents)