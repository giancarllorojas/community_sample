## Code Sample

I've worked two weeks on this project. The first week was mainly prototyping the UI in Figma. The second week, I've started implementing the design components using Nuxt & Vue, so there's no backend. Unfortunately, the client had an issue with his investors and asked me to pause the project indefinitely.

You can preview the project at https://wonderful-poincare-86bebc.netlify.app/.

Running locally:
yarn install
yarn dev

Then access it at http://localhost:3000.